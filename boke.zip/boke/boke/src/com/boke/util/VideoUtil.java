package com.boke.util;

import java.io.File;
import java.util.List;

public class VideoUtil {
//	public static void main(String[] args) {
//		VideoToVideo("D:/videotest/zhang.avi",
//				"����/WebRoot/tools/ffmpeg.exe",
//				"D:/videotest/tttttttt.flv");
//	}
	
	public static boolean VideoToPicture(String veido_path,String ffmpeg_path, String picPath) {  
		File file = new File(veido_path);  
		if (!file.exists()) {  
			System.err.println("该路径[" + veido_path + "]不存在");  
			return false;  
		} 	
		List<String> commands = new java.util.ArrayList<String>();  
		commands.add(ffmpeg_path);  
		commands.add("-ss");  
		commands.add("10");
		commands.add("-i");  
		commands.add(veido_path);  
		commands.add("-y");  
		commands.add("-f");  
		commands.add("image2");  
		 
		commands.add("-t");  
		commands.add("0.001");  
		commands.add("-s");  
		commands.add("400*300");  
		commands.add(picPath);  
	   try {  
			ProcessBuilder builder = new ProcessBuilder();  
			builder.command(commands);  
			builder.redirectErrorStream(true);
			builder.start();  
			
			System.out.println("截图成功");  
		   return true;  
	   	} catch (Exception e) {  
		   e.printStackTrace();  
		   return false;  
	    }  
	} 

	
	public static boolean VideoToVideo(String veidopath,String ffmpegpath, String codcFilePath) { 
		
		File file = new File(veidopath);  
		if (!file.exists()) {  
			System.err.println("该路径[" + veidopath + "]不存在");  
			return false;  
		} 	
		
		List<String> commands = new java.util.ArrayList<String>();  
        commands.add(ffmpegpath); 
        commands.add("-i"); 
        commands.add(veidopath); 
        commands.add("-qscale");     
        commands.add("6");
        commands.add("-ab");        
        commands.add("64");
        commands.add("-ac");        
        commands.add("2");
        commands.add("-ar");        
        commands.add("22050");
        commands.add("-r");        
        commands.add("24");
        commands.add("-y"); 
        commands.add(codcFilePath);  
	   try {  
		   
			ProcessBuilder builder = new ProcessBuilder();  
			builder.command(commands);
	        builder.redirectErrorStream(true);
	        builder.start();
	        
			System.out.println("转码成功"); 
		   
			//File f=new File(veidopath);
			//f.delete();
			//System.out.println("删除成功");
		   return true;  
	   	} catch (Exception e) {  
		   e.printStackTrace();  
		   return false;  
	    }  
	}
}

