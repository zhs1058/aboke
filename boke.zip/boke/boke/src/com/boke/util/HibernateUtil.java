package com.boke.util;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.boke.entity.Case;
import com.boke.entity.Logininformation;
import com.boke.entity.Video;
import com.boke.util.HibernateUtil;

public class HibernateUtil {
	private HibernateUtil() {
	}
	private static SessionFactory sessionFactory;

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public static void setSessionFactory(SessionFactory sessionFactory) {
		HibernateUtil.sessionFactory = sessionFactory;
	}
	
	
	public static Session getSession() {
		return sessionFactory.openSession();
	}
	
	
	
	public static void addvideo(Object entity) {
			
			Session session = (Session) HibernateUtil.getSession();
			Transaction transaction = session.beginTransaction();
			session.save(entity);
			transaction.commit();
			if(session!=null) session.close();
		
	}
	public static ArrayList<Video> selecttag(String  flag){
		Session session=(Session)HibernateUtil.getSession();
		
		String sql="from Case f where f.flag=? order by id desc";
		String hql="select v.vid v.picturedir v.videodir  from Video as v,Tag as t where v.vid=t.vid and t.?=1";
		Query query=session.createQuery(hql).setParameter(0, flag);
		@SuppressWarnings("unchecked")
		ArrayList<Video> videos=(ArrayList<Video>) query.list();
		
		if(session!=null) session.close();
		
	
		return videos;
	}
	public static ArrayList<Video> selectall(){
		
			Session session=(Session)HibernateUtil.getSession();
			//Transaction transaction=session.beginTransaction();
			String sql="from Video v order by vid desc";
			Query query=session.createQuery(sql);
			@SuppressWarnings("unchecked")
			ArrayList<Video> videos=(ArrayList<Video>) query.list();
			
			if(session!=null) session.close();
			
		
			return videos;	
	}
	public static void del(String id){
		
		Session session=(Session)HibernateUtil.getSession();
		Transaction transaction=session.beginTransaction();
		Case file=(Case)session.load(Case.class, id);
		session.delete(file);
		transaction.commit();
		if(session!=null) session.close();
		
	}

	public static boolean check(Logininformation entity) {
		// TODO Auto-generated method stub
		Session session=(Session)HibernateUtil.getSession();
		String sql="select password from Logininformation where name=? and password=?";
		
		Query query=session.createQuery(sql);
		query.setParameter(0, entity.getName());
		query.setParameter(1, entity.getPassword());
		
		if(query.list().isEmpty()) return false;
		else return true;
		
		//Query query=session.createQuery(sql).setParameter(0, entity.getName());
		
		
//		if(query.list().isEmpty()) return false;
//		@SuppressWarnings("unchecked")
//		ArrayList<String> infors=(ArrayList<String>) query.list();
//		String ps=null;
//		for(String infor:infors){
//			ps=infor;
//		}
//		if(ps.equals(entity.getPassword())) return true;
//		else return false;
	}
	
}
