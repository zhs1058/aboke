package com.boke.action;

import java.io.IOException;
import java.util.Map;






import javax.servlet.http.HttpSession;

import com.boke.entity.Logininformation;
import com.boke.impl.Checknameimpl;
import com.boke.inter.Checknameinter;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;



@SuppressWarnings("serial")
public class loginaction extends ActionSupport {
	
	private String name;
	private String password;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@SuppressWarnings("unchecked")
	public String execute() throws IOException{
		Checknameinter check=new Checknameimpl();
		Logininformation infor=new Logininformation();
		infor.setName(name);
		infor.setPassword(password);
		ActionContext ac = ActionContext.getContext();
        @SuppressWarnings("rawtypes")
        Map session = ac.getSession();
		if(check.check(infor)&&session.get("username")!=name) {
			session.put("username", name);
			return SUCCESS;
		}
		else return LOGIN;
		
		
	}

}
