package com.boke.action;

import com.opensymphony.xwork2.ActionSupport;

public class playaction extends ActionSupport {
	private String videodir;
	
	public String getVideodir() {
		return videodir;
	}
	public void setVideodir(String videodir) {
		this.videodir = videodir;
	}
	
	public String execute(){
		System.out.println(videodir);
		
		
		
		return SUCCESS;
	}

}
