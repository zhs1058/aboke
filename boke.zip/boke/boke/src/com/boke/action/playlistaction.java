package com.boke.action;

import java.util.ArrayList;

import com.boke.entity.Video;
import com.boke.impl.Selectallimpl;
import com.boke.inter.Selectallinter;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class playlistaction extends ActionSupport {
	private ArrayList<Video> videos;
	private Integer videolength;
	

	public ArrayList<Video> getVideos() {
		return videos;
	}

	public void setVideos(ArrayList<Video> videos) {
		this.videos = videos;
	}

	public Integer getVideolength() {
		return videolength;
	}

	public void setVideolength(Integer videolength) {
		this.videolength = videolength;
	}

	public String execute(){
		Selectallinter select = new Selectallimpl();
		videos=select.selectall();
		videolength=videos.size();
		
		return SUCCESS;
		
	}
}
