package com.boke.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.tomcat.util.http.fileupload.IOUtils;

import com.boke.entity.Video;
import com.boke.impl.Addvideoimpl;
import com.boke.inter.Addvideointer;
import com.boke.util.VideoUtil;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class uploadaction extends ActionSupport {
	
	
	private File videoName;
	private String title;
	private String describe;
	public File getVideoName() {
		return videoName;
	}
	public void setVideoName(File videoName) {
		this.videoName = videoName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescribe() {
		return describe;
	}
	public void setDescribe(String describe) {
		this.describe = describe;
	}
	public String execute() throws IOException{
		Addvideointer add=new Addvideoimpl();
		String path = "D:\\Mcode\\boke\\WebRoot\\tmpvideo\\";
		Video videos= new Video();
		Date date = new Date();
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
		String time = format.format(date);
		System.out.println("现在时间是"+time);
		String fname = time + ".avi";
		FileOutputStream outer= new FileOutputStream(path+fname);
		FileInputStream iner=new FileInputStream(videoName);
		IOUtils.copy(iner, outer);
		outer.flush();
		outer.close();
		iner.close();
		
		String ffmpegpath="D:\\Mcode\\boke\\WebRoot\\tools\\ffmpeg.exe";
		String codcFilePath="D:\\Mcode\\boke\\WebRoot\\video\\"+time+".flv";
		String picPath="D:\\Mcode\\boke\\WebRoot\\picture\\"+time+".png";
		
		String xdp=picPath;
		String xdv=codcFilePath;
		
		String xdpicturedir=xdp.substring(xdp.lastIndexOf("i")-1, xdp.length());
		String xdvideodir=xdv.substring(xdv.lastIndexOf("i")-1, xdv.length());
		VideoUtil.VideoToPicture(path+fname, ffmpegpath, picPath);
		VideoUtil.VideoToVideo(path+fname, ffmpegpath, codcFilePath);
		videos.setVid(time);
		videos.setTitle(title);
		videos.setDescribe(describe);
		videos.setVideodir(codcFilePath);
		videos.setPicturedir(picPath);
		videos.setXdpicturedir(xdpicturedir);
		videos.setXdvideodir(xdvideodir);
		videos.setVodeostatic(0);
		add.addvideo(videos);
		return SUCCESS;
		
	}

}
