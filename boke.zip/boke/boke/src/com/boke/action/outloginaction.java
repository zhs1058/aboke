package com.boke.action;

import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;








import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class outloginaction extends ActionSupport {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String execute(){
		 ActionContext ac = ActionContext.getContext();
         @SuppressWarnings("rawtypes")
         Map session = ac.getSession();
         session.clear();
         
         return SUCCESS;
	}

}
