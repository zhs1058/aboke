package com.boke.inter;

public interface Addvideointer {
	public abstract void addvideo(Object entity);
}
