package com.boke.inter;

import com.boke.entity.Logininformation;

public interface Checknameinter {
	public abstract boolean check(Logininformation entity);
}
