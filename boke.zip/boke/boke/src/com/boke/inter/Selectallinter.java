package com.boke.inter;

import java.util.ArrayList;

import com.boke.entity.Video;

public interface Selectallinter {
	public abstract ArrayList<Video> selectall();
}
