package com.boke.impl;

import com.boke.entity.Logininformation;
import com.boke.inter.Checknameinter;
import com.boke.util.HibernateUtil;

public class Checknameimpl implements Checknameinter {
	public boolean check(Logininformation entity){
		return HibernateUtil.check(entity);
	}

}
