package com.boke.impl;

import java.util.ArrayList;

import com.boke.entity.Video;
import com.boke.inter.Selectallinter;
import com.boke.util.HibernateUtil;

public class Selectallimpl implements Selectallinter {
	public ArrayList<Video> selectall(){
		return HibernateUtil.selectall();
	}

}
