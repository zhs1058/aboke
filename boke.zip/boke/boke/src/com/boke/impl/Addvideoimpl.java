package com.boke.impl;

import com.boke.inter.Addvideointer;
import com.boke.util.HibernateUtil;

public class Addvideoimpl implements Addvideointer {

	public void addvideo(Object entity) {
		HibernateUtil.addvideo(entity);
		
	}
	

}
