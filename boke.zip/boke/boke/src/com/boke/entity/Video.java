package com.boke.entity;

public class Video {
	private String vid;
	private String title;
	private String describe;
	private String videodir;
	private String picturedir;
	private String xdvideodir;
	private String xdpicturedir;
	private int vodeostatic;
	
	public String getXdvideodir() {
		return xdvideodir;
	}
	public void setXdvideodir(String xdvideodir) {
		this.xdvideodir = xdvideodir;
	}
	public String getXdpicturedir() {
		return xdpicturedir;
	}
	public void setXdpicturedir(String xdpicturedir) {
		this.xdpicturedir = xdpicturedir;
	}
	public String getVid() {
		return vid;
	}
	public void setVid(String vid) {
		this.vid = vid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescribe() {
		return describe;
	}
	public void setDescribe(String describe) {
		this.describe = describe;
	}
	public String getVideodir() {
		return videodir;
	}
	public void setVideodir(String videodir) {
		this.videodir = videodir;
	}
	public String getPicturedir() {
		return picturedir;
	}
	public void setPicturedir(String picturedir) {
		this.picturedir = picturedir;
	}
	public int getVodeostatic() {
		return vodeostatic;
	}
	public void setVodeostatic(int vodeostatic) {
		this.vodeostatic = vodeostatic;
	}
	
	
	
}
