package com.boke.entity;

public class Case {
	private String timeid;
	private String dir;
	private String content;
	private int flag;
	
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public String getTimeid(){
		return timeid;
	}
	public void setTimeid(String timeid){
		this.timeid=timeid;
	}
	public String getDir(){
		return dir;
	}
	public void setDir(String dir){
		this.dir=dir;
	}
	public String getContent(){
		return content;
	}
	public void setContent(String content){
		this.content=content;
	}
}
